var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./ColorfulOptionSetButton/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./ColorfulOptionSetButton/index.ts":
/*!******************************************!*\
  !*** ./ColorfulOptionSetButton/index.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.NewColorfulOptionSetButton = void 0;\n\nclass NewColorfulOptionSetButton {\n  constructor() {}\n\n  init(context, notifyOutputChanged, state, container) {\n    var _a, _b;\n\n    this.theContainer = container;\n    this.theContext = context;\n    this.theNotifyChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(false);\n    this.optionSetArray = (_a = context.parameters.OptionSetAttribute.attributes) === null || _a === void 0 ? void 0 : _a.Options;\n    this._defaultValue = (_b = context.parameters.OptionSetAttribute.attributes) === null || _b === void 0 ? void 0 : _b.DefaultValue;\n    let currentInputData = context.parameters.OptionSetAttribute.raw || null;\n\n    if (currentInputData != null) {\n      this._outputValue = currentInputData;\n    } else {\n      if (this._defaultValue) {\n        this._outputValue = this._defaultValue;\n      }\n    }\n\n    this.eleMainContainer = document.createElement(\"div\");\n    this.eleMainContainer.id = \"mybtn\";\n    this.eleMainContainer.className = \"btn-group\";\n\n    if (this.optionSetArray) {\n      let width = 100 / this.optionSetArray.length;\n\n      for (var i = 0; i < this.optionSetArray.length; i++) {\n        let eleButton;\n        eleButton = document.createElement(\"button\");\n        eleButton.innerHTML = this.optionSetArray[i].Label;\n        eleButton.id = this.optionSetArray[i].Value.toString();\n        eleButton.style.width = width.toString() + \"%\";\n        eleButton.style.background = \"#6f6f6f\";\n        eleButton.addEventListener(\"click\", this.onButtonClick.bind(this));\n        this.eleMainContainer.appendChild(eleButton);\n      }\n    }\n\n    container.appendChild(this.eleMainContainer);\n  }\n\n  updateView(context) {\n    if (this.eleMainContainer.children.length > 0) {\n      for (var i = 0; i < this.eleMainContainer.children.length; i++) {\n        let elementButton = this.eleMainContainer.children[i];\n\n        if (this._outputValue && elementButton.id !== this._outputValue.toString()) {\n          elementButton.style.background = \"#6f6f6f\";\n        } else if (this._outputValue && elementButton.id === this._outputValue.toString()) {\n          if (this.optionSetArray) {\n            var result = this.optionSetArray.filter(obj => {\n              return obj.Value === parseInt(elementButton.id);\n            });\n            elementButton.style.background = result[0].Color;\n          }\n        } else if (!this._outputValue) {\n          elementButton.style.background = \"#6f6f6f\";\n        }\n\n        elementButton.disabled = context.mode.isControlDisabled;\n      }\n    }\n  }\n\n  getOutputs() {\n    return {\n      OptionSetAttribute: this._outputValue == null ? -1 : this._outputValue\n    };\n  }\n\n  onButtonClick(event) {\n    var _a;\n\n    let selectedElement = event.target;\n\n    if (this._defaultValue && this._defaultValue > -1) {\n      if (selectedElement) this._outputValue = parseInt(selectedElement.id);\n    } else {\n      if (selectedElement.id === ((_a = this._outputValue) === null || _a === void 0 ? void 0 : _a.toString())) {\n        this._outputValue = null;\n      } else {\n        if (selectedElement) this._outputValue = parseInt(selectedElement.id);\n      }\n    }\n\n    this.theNotifyChanged();\n  }\n\n  destroy() {}\n\n}\n\nexports.NewColorfulOptionSetButton = NewColorfulOptionSetButton;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ColorfulOptionSetButton/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('dev.NewColorfulOptionSetButton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NewColorfulOptionSetButton);
} else {
	var dev = dev || {};
	dev.NewColorfulOptionSetButton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NewColorfulOptionSetButton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}